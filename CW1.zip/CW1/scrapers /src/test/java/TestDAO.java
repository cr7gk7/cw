import eu.webscraping.ShirtsDAO;
import eu.webscraping.ShirtsCompare;
import eu.webscraping.ShirtsInstance;
import eu.webscraping.ShirtsModel;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Class test from where functions are tested
 */
@DisplayName("Test ShirtsDAO")
public class TestDAO {

    private static SessionFactory sessionFactory;
    private static ShirtsDAO shirtsDAO = new ShirtsDAO();

    /**
     * Initialise session factory
     */
    @BeforeAll
    static void initAll() {

        try {
            //Create a builder for the standard service registry
            StandardServiceRegistryBuilder standardServiceRegistryBuilder = new StandardServiceRegistryBuilder();

            //Load configuration from hibernate configuration file
            standardServiceRegistryBuilder.configure("test_hibernate.cfg.xml");

            //Create the registry that will be used to build the session factory
            StandardServiceRegistry registry = standardServiceRegistryBuilder.build();

            try {

                //Create the session factory - this is the goal of the init method.
                sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();

            } catch (Exception e) {

                //The registry would be destroyed by the SessionFactory
                System.err.println("Session factory build failed!");
                e.printStackTrace();
                StandardServiceRegistryBuilder.destroy(registry);

            }

            //Output result
            System.out.println("Session factory build!");

        } catch (Throwable ex) {

            // Make sure you log the exception, as it might be swallowed
            System.err.println("Session factory creation failed: " + ex);

        }

        shirtsDAO.setSessionFactory(sessionFactory);

    }

    @BeforeEach
    void init() {
    }

    /**
     * Test from where function add shirts is tested by adding
     * a shirts to database and checking if id is different from 0
     */
    @Test
    @DisplayName("Test add shirts model")
    void testAddShirtsModel() {

        ShirtsModel shirtsModel = new ShirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        assertEquals(shirtsModel.getId(), 0);

        try {
            assertNotEquals(shirtsDAO.addShirtsModel(shirtsModel).getId(), 0);
        } catch (Exception ex) {
            fail("Failed to add shirts model. Exception thrown: " + ex.getMessage());
        }
    }

    /**
     * Test from where function add instance is tested by adding
     * a shirts to database and checking if id is different from 0
     */
    @Test
    @DisplayName("Test add shirts instance")
    void testAddShirtsInstance() {

        ShirtsModel shirtsModel = new ShirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        ShirtsInstance shirtsInstance = new ShirtsInstance();
        shirtsInstance.setShirtsModel(shirtsModel);
        shirtsInstance.setColor("Blue");
        shirtsInstance.setSize("XS, M, L, XL");
        shirtsInstance.setDescription("Brand Model1");
        shirtsInstance.setImageURL("www.example.com");

        assertEquals(shirtsInstance.getId(), 0);

        try {
            assertNotEquals(shirtsDAO.addShirtsInstance(shirtsInstance).getId(), 0);
        } catch (Exception ex) {
            fail("Failed to add shirts model. Exception thrown: " + ex.getMessage());
        }
    }

    /**
     * Test from where function add comparison is tested by adding
     * a shirts to database and checking if id is different from 0
     */
    @Test
    @DisplayName("Test add shirts comparison")
    void testAddshirtsComparison() {

        ShirtsModel shirtsModel = new ShirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        ShirtsInstance shirtsInstance = new ShirtsInstance();
        shirtsInstance.setShirtsModel(shirtsModel);
        shirtsInstance.setColor("Blue");
        shirtsInstance.setSize("XS, M, L, XL");
        shirtsInstance.setDescription("Brand Model1");
        shirtsInstance.setImageURL("www.example.com");

        ShirtsCompare shirtsComparison = new ShirtsCompare();
        shirtsComparison.setPrice(100f);
        shirtsComparison.setShirtsInstance(shirtsInstance);
        shirtsComparison.setWebsiteURL("www.example.com");

        assertEquals(shirtsComparison.getId(), 0);

        try {
            assertNotEquals(shirtsDAO.addShirtsComparison(shirtsComparison).getId(), 0);
        } catch (Exception ex) {
            fail("Failed to add shirts comparison. Exception thrown: " + ex.getMessage());
        }
    }

    /**
     * Test from where function find shirts model is tested by
     * checking the database for a specific model and if model
     * is not found function will add model to database
     */
    /*@Test
    @DisplayName("Test find shirts model")
    void testFindshirtsModel() {

        shirtsModel shirtsModel = new shirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        try {
            assertEquals(shirtsDAO.findshirtsModel(shirtsModel).getId(), 7);
        } catch (Exception ex) {
            fail("Failed to find shirts model. Exception thrown: " + ex.getMessage());
        }
    }
*/
    /**
     * Test from where function find shirts instance is tested by
     * checking the database for a specific instance and if model
     * is not found function will add instanec to database
     */
   /* @Test
    @DisplayName("Test find shirts instance")
    void testFindshirtsInstance() {

        shirtsModel shirtsModel = new shirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        shirtsInstance shirtsInstance = new shirtsInstance();
        shirtsInstance.setshirtsModel(shirtsDAO.findshirtsModel(shirtsModel));
        shirtsInstance.setColor("Blue");
        shirtsInstance.setSize("XS, M, L, XL");
        shirtsInstance.setDescription("Brand Model1");
        shirtsInstance.setImageURL("www.example.com");

        try {
            assertEquals(shirtsDAO.findshirtsInstance(shirtsInstance).getId(), 5);
        } catch (Exception ex) {
            fail("Failed to find shirts instance. Exception thrown: " + ex.getMessage());
        }
    }*/

    /**
     * Test from where function find shirts comparison is tested by
     * checking the database for a specific comparison and if model
     * is not found function will add comparison to database
     */
  /*  @Test
    @DisplayName("Test find shirts comparison")
    void testFindshirtsComparison() {

        shirtsModel shirtsModel = new shirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        shirtsInstance shirtsInstance = new shirtsInstance();
        shirtsInstance.setshirtsModel(shirtsDAO.findshirtsModel(shirtsModel));
        shirtsInstance.setColor("Blue");
        shirtsInstance.setSize("XS, M, L, XL");
        shirtsInstance.setDescription("Brand Model1");
        shirtsInstance.setImageURL("www.example.com");

        shirtsComparison shirtsComparison = new shirtsComparison();
        shirtsComparison.setshirtsInstance(shirtsDAO.findshirtsInstance(shirtsInstance));
        shirtsComparison.setPrice(100f);
        shirtsComparison.setWebsiteURL("www.example.com");

        try {
            assertEquals(shirtsDAO.findshirtsComparison(shirtsComparison).getId(), 3);
        } catch (Exception ex) {
            fail("Failed to find shirts comparison. Exception thrown: " + ex.getMessage());
        }
    }*/

    @Test
    @DisplayName("Test update shirts instance")
    void testUpdateshirtsInstance() {

        ShirtsModel shirtsModel = new ShirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        ShirtsInstance shirtsInstance = new ShirtsInstance();
        shirtsInstance.setId(5);
        shirtsInstance.setShirtsModel(shirtsDAO.findShirtsModel(shirtsModel));
        shirtsInstance.setColor("Blue");
        shirtsInstance.setSize("XS, M, L, XL");
        shirtsInstance.setDescription("Brand Model1");
        shirtsInstance.setImageURL("www.example.com");

        try {
            assertEquals(shirtsDAO.updateInstance(shirtsInstance).getColor(), "Blue");
        } catch (Exception ex) {
            fail("Failed to find shirts comparison. Exception thrown: " + ex.getMessage());
        }
    }

    @Test
    @DisplayName("Test update shirts comparison")
    void testUpdateshirtsComparison() {

        ShirtsModel shirtsModel = new ShirtsModel();
        shirtsModel.setManufacturer("Brand");
        shirtsModel.setModel("Model1");

        ShirtsInstance shirtsInstance = new ShirtsInstance();
        shirtsInstance.setId(5);
        shirtsInstance.setShirtsModel(shirtsDAO.findShirtsModel(shirtsModel));
        shirtsInstance.setColor("Blue");
        shirtsInstance.setSize("XS, M, L, XL");
        shirtsInstance.setDescription("Brand Model1");
        shirtsInstance.setImageURL("www.example.com");

        ShirtsCompare shirtsComparison = new ShirtsCompare();
        shirtsComparison.setId(3);
        shirtsComparison.setShirtsInstance(shirtsDAO.findShirtsInstance(shirtsInstance));
        shirtsComparison.setPrice(200f);
        shirtsComparison.setWebsiteURL("www.example.com");

        try {
            assertEquals(shirtsDAO.updateComparison(shirtsComparison).getPrice(), 200f);
        } catch (Exception ex) {
            fail("Failed to find shirts comparison. Exception thrown: " + ex.getMessage());
        }
    }

    @AfterEach
    void tearDown() {
    }

    /**
     * Close session factory
     */
    @AfterAll
    static void tearDownAll() {
        shirtsDAO.shutDown();
    }
}
