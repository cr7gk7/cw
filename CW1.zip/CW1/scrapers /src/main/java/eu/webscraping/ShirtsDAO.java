package eu.webscraping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * This class is the ShirtsDAO
 * which contains the functions
 * to add, update anf find shirtss
 * from database
 */
public class ShirtsDAO {

    /**
     * Creates new sessions when needed to interact with the database
     */
    //Creates new Sessions when we needed to interact with the database
    SessionFactory sessionFactory;

    /**
     * This function adds shirts model to database and returns the shirts added
     * @param shirtsModel
     * @return shirtsModel
     */
    //Add shirts model
    public ShirtsModel addShirtsModel(ShirtsModel shirtsModel) {

        //Get a new Session instance from the session factory
        Session session = sessionFactory.getCurrentSession();

        //Start transaction
        session.beginTransaction();

        session.save(shirtsModel);

        //Commit transaction to save it to database
        session.getTransaction().commit();

        //Close the session and release database connection
        session.close();
        System.out.println("Shirts model added to database with ID: " + shirtsModel.getId());

        return shirtsModel;
    }


    /**
     * This function adds shirts instance to database and returns the shirts added
     * @param shirtsInstance
     * @return shirtsInstance
     */
    //Add shirts instance
    public ShirtsInstance addShirtsInstance(ShirtsInstance shirtsInstance) {

        //Get a new Session instance from the session factory
        Session session = sessionFactory.getCurrentSession();

        //Start transaction
        session.beginTransaction();

        session.save(shirtsInstance);

        //Commit transaction to save it to database
        session.getTransaction().commit();

        //Close the session and release database connection
        session.close();
        System.out.println("shirts added instance to database with ID: " + shirtsInstance.getId());

        return shirtsInstance;
    }


    /**
     * This function adds shirts comparison to database and returns the shirts added
     * @param shirtsComparison
     * @return shirtsComparison
     */
    //Add shirts comparison
    public ShirtsCompare addShirtsComparison(ShirtsCompare shirtsComparison) {

        //Get a new Session instance from the session factory
        Session session = sessionFactory.getCurrentSession();

        //Start transaction
        session.beginTransaction();

        session.save(shirtsComparison);

        //Commit transaction to save it to database
        session.getTransaction().commit();

        //Close the session and release database connection
        session.close();
        System.out.println("shirts comparison added to database with ID: " + shirtsComparison.getId());

        return shirtsComparison;
    }


    /**
     * This function finds and returns shirts model if shirts not found the function adds shirts model to database
     * @param shirtsModel
     * @return shirtsModel
     */
    //Find shirts model
    public ShirtsModel findShirtsModel(ShirtsModel shirtsModel) {

        //Get a new Session instance from the session factory and start transaction
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();

        String queryStr = "from ShirtsModel where manufacturer='" + shirtsModel.getManufacturer() + "' AND model='" + shirtsModel.getModel() + "'";

        //Get class
        List<ShirtsModel> shirtsModelList = session.createQuery(queryStr).getResultList();

        //Close the session and release database connection
        session.close();

        if (shirtsModelList.size() == 1) {

            return shirtsModelList.get(0);

        } else {

            return addShirtsModel(shirtsModel);
        }
    }


    /**
     * This function finds and returns shirts instance if shirts not found the function adds shirts instance to database
     * @param shirtsInstance
     * @return shirtsInstance
     */
    //Find shirts instance
    public ShirtsInstance findShirtsInstance(ShirtsInstance shirtsInstance) {

        //Get a new Session instance from the session factory and start transaction
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();

        String queryStr = "from shirtsInstance where shirts_model_id='" + shirtsInstance.getShirtsModel().getId() + "'";

        //Get class
        List<ShirtsInstance> shirtsInstanceList = session.createQuery(queryStr).getResultList();

        //Close the session and release database connection
        session.close();

        if (shirtsInstanceList.size() == 1) {

            shirtsInstance.setId(shirtsInstanceList.get(0).getId());
            updateInstance(shirtsInstance);
            return shirtsInstanceList.get(0);

        } else {

            return addShirtsInstance(shirtsInstance);

        }
    }


    /**
     * This function finds and returns shirts comparison if shirts not found the function adds shirts comparison to database
     * @param shirtsComparison
     * @return shirtsComparison
     */
    //Find comparison
    public ShirtsCompare findShirtsComparison(ShirtsCompare shirtsComparison) {

        ShirtsCompare newShirtsComparison = new ShirtsCompare();

        //Get a new Session instance from the session factory and start transaction
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();

        String queryStr = "from ShirtsComparison where website_url='" + shirtsComparison.getWebsiteURL() + "'";

        //Get class
        List<ShirtsCompare> shirtsComparisonList = session.createQuery(queryStr).getResultList();

        //Close the session and release database connection
        session.close();

        if(shirtsComparisonList.size() == 0){

            newShirtsComparison = addShirtsComparison(shirtsComparison);

        } else {

            for (ShirtsCompare comparison : shirtsComparisonList) {

                if (comparison.getWebsiteURL() == shirtsComparison.getWebsiteURL()) {
                    shirtsComparison.setId(comparison.getId());
                    newShirtsComparison = updateComparison(shirtsComparison);
                    break;
                }
            }
        }

        return newShirtsComparison;
    }

    /**
     * This function updates shirts comparison price
     * @param shirtsInstance
     * @return shirtsInstance
     */
    public ShirtsInstance updateInstance(ShirtsInstance shirtsInstance) {

        Session session = sessionFactory.getCurrentSession();

        session.beginTransaction();

        String queryStr = "from ShirtsInstance where id='" + shirtsInstance.getId() + "'";
        List<ShirtsInstance> shirtsInstanceList = session.createQuery(queryStr).getResultList();

        if (shirtsInstanceList.size() == 1) {

            if (shirtsInstanceList.get(0).getSize().contains("N/A")) {
                shirtsInstanceList.get(0).setSize(shirtsInstance.getSize());
            }

            if (shirtsInstanceList.get(0).getColor().contains("N/A")) {
                shirtsInstanceList.get(0).setColor(shirtsInstance.getColor());
            }
        }

        session.getTransaction().commit();

        return shirtsInstanceList.get(0);
    }


    /**
     * This function updates shirts comparison price
     * @param shirtsComparison
     * @return shirtsComparison
     */
    public ShirtsCompare updateComparison(ShirtsCompare shirtsComparison) {

        Session session = sessionFactory.getCurrentSession();

        session.beginTransaction();

        String queryStr = "from shirtsComparison where id='" + shirtsComparison.getId() + "'";
        List<ShirtsCompare> shirtsComparisonList = session.createQuery(queryStr).getResultList();

        if (shirtsComparisonList.size() == 1) {

            if (shirtsComparisonList.get(0).getWebsiteURL().contains(shirtsComparison.getWebsiteURL()))
                shirtsComparisonList.get(0).setPrice(shirtsComparison.getPrice());
        }

        session.getTransaction().commit();

        return shirtsComparisonList.get(0);
    }


    /**
     * This function closes session factory
     */
    //Close Hibernate down and stop threads from running
    public void shutDown() {
        sessionFactory.close();
    }


    /**
     * Return session factory
     * @return session factory
     */
    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }


    /**
     * Set session factory
     * @param sessionFactory
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
