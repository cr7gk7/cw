package eu.webscraping;

import javax.persistence.*;

/**
 * Class mapped to shirts_comparison table
 */
@Entity
@Table(name = "shirts_comparison")
public class ShirtsCompare {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "shirts_instance_id", nullable = false)
    ShirtsInstance shirtsInstance;

    @Column(name = "price")
    private Float price;

    @Column(name = "website_url")
    private String websiteURL;

    public ShirtsCompare() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ShirtsInstance getShirtsInstance() {
        return shirtsInstance;
    }

    public void setShirtsInstance(ShirtsInstance shirts_instance_id) {
        this.shirtsInstance = shirts_instance_id;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public String getWebsiteURL() {
        return websiteURL;
    }

    public void setWebsiteURL(String websiteURL) {
        this.websiteURL = websiteURL;
    }

    @Override
    public String toString() {
        return "ShirtsComparison{" +
                "id=" + id +
                ", shirtsInstance=" + shirtsInstance +
                ", price=" + price +
                ", websiteURL='" + websiteURL + '\'' +
                '}';
    }

    public void setShirtsInstance(ShirtsInstance shirtsInstance) {
    }
}
