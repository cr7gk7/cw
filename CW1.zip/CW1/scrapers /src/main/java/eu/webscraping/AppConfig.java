package eu.webscraping;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;

/**
 * This class initialises session factory,
 * scrapers and get them ready to scrape
 */
@Configuration
public class AppConfig {

    SessionFactory sessionFactory;

    /**
     * @return scraperManager array containing all the scrapers
     * set and ready to scrape
     */
    @Bean
    public WebScraperManager scraperManager() {

        WebScraperManager scraperManager = new WebScraperManager();
        final ArrayList<WebScraper> scraperArrayList = new ArrayList();
        scraperArrayList.add(footy());
        scraperArrayList.add(goJersey());
        scraperArrayList.add(sportsDirect());
        scraperArrayList.add(kitbag());
        scraperArrayList.add(jdSports());
        scraperManager.setWebScraperArrayList(scraperArrayList);

        return scraperManager;
    }

    /**
     * @return scraper1 with shirtsDAO and
     * scrape delay initialise
     */
    @Bean
    public Footy footy() {

        Footy scraper1 = new Footy();
        scraper1.setShirtsDA(shirtsDAO());
        scraper1.setScrapeDelay(10000);

        return scraper1;
    }

    /**
     * @return scraper2 with shirtsDAO and
     * scrape delay initialise
     */
    @Bean
    public GoJersey goJersey() {

        GoJersey scraper2 = new GoJersey();
        scraper2.setShirtsDAO(shirtsDAO());
        scraper2.setScrapeDelay(20000);

        return scraper2;
    }

    /**
     * @return scraper3 with shirtsDAO and
     * scrape delay initialise
     */
    @Bean
    public SportsDirect sportsDirect() {

        SportsDirect scraper3 = new SportsDirect();
        scraper3.setShirtsDAO(shirtsDAO());
        scraper3.setScrapeDelay(30000);

        return scraper3;
    }

    /**
     * @return scraper4 with shirtsDAO and
     * scrape delay initialise
     */
    @Bean
    public Kitbag kitbag() {

        Kitbag scraper4 = new Kitbag();
        scraper4.setShirtsDAO(shirtsDAO());
        scraper4.setScrapeDelay(40000);

        return scraper4;
    }

    /**
     * @return scraper5 with shirtsDAO and
     * scrape delay initialise
     */
    @Bean
    public JDsports jdSports() {

        JDsports scraper5 = new JDsports();
        scraper5.setShirtsDAO(shirtsDAO());
        scraper5.setScrapeDelay(50000);

        return scraper5;
    }

    /**
     * @return shirtsDAO with session factory initialise
     */
    @Bean
    public ShirtsDAO shirtsDAO() {

        ShirtsDAO shirtsDAO = new ShirtsDAO();
        shirtsDAO.setSessionFactory(sessionFactory());

        return shirtsDAO;
    }

    /**
     * @return session factory that was build based on
     * the hibernate.cfg.xml
     */
    @Bean
    public SessionFactory sessionFactory() {

        if (sessionFactory == null) {

            //Set up the session factory
            try {
                //Create a builder for the standard service registry
                StandardServiceRegistryBuilder standardServiceRegistryBuilder = new StandardServiceRegistryBuilder();

                //Load configuration from hibernate configuration file
                standardServiceRegistryBuilder.configure("hibernate.cfg.xml");

                //Create the registry that will be used to build the session factory
                StandardServiceRegistry registry = standardServiceRegistryBuilder.build();

                try {

                    //Create the session factory - this is the goal of the init method.
                    sessionFactory = new MetadataSources(registry).buildMetadata().buildSessionFactory();

                } catch (Exception e) {

                    //The registry would be destroyed by the SessionFactory
                    System.err.println("Session factory build failed!");
                    e.printStackTrace();
                    StandardServiceRegistryBuilder.destroy(registry);

                }

                //Output result
                System.out.println("Session factory build!");

            } catch (Throwable ex) {

                // Make sure you log the exception, as it might be swallowed
                System.err.println("Session factory creation failed: " + ex);

            }
        }
        return sessionFactory;
    }
}
