package eu.webscraping;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * EvansCycle class from where shirts are loaded to database
 */
public class Footy extends WebScraper {

    /**
     * Function to run thread
     */
    @Override
    public void run() {

        //While loop will keep running until runThread is set to false
        while (this.setRunThread()) {

            try {

                //Array that contains all urls to be scraped
                String[] query = {"https://www.footy.com/c/football-kits/premier-league/"};

                for (int i = 0; i < query.length; i++) {

                    WebDriver driver = new ChromeDriver();

                    driver.get(query[i]);

                    Document doc = Jsoup.parse(driver.getPageSource());

                    Elements products = doc.select("div .columns3 .s-productscontainer2 li");

                    for (int j = 0; j < products.size(); j++) {

                        Elements size = products.get(j).select("li .sizeDetail");

                        Elements image = products.get(j).select("li .ProductImageList .rtimg");

                        String url = products.get(j).attr("li-url");

                        String brand = products.get(j).attr("li-brand");

                        String filter = products.get(j).attr("li-name");

                        String model = filter.replaceAll("Preimer League Shirts | 2021 | 2022 | 2023", "").trim();

                        String description = brand + " " + filter;

                        String color = products.get(j).attr("li-variant");

                        String price = products.get(j).attr("li-price");

                        String img = image.attr("src");

                        //Set and add shirts model to database
                        ShirtsModel shirtsModel = new ShirtsModel();
                        shirtsModel.setManufacturer(brand);
                        shirtsModel.setModel(model);
                        this.getShirtsDAO().findShirtsModel(shirtsModel);

                        //Set and add shirts instance to database
                        ShirtsInstance shirtsInstance = new ShirtsInstance();
                        shirtsInstance.setShirtsModel(this.getShirtsDAO().findShirtsModel(shirtsModel));
                        shirtsInstance.setDescription(description);
                        shirtsInstance.setColor(color);
                        shirtsInstance.setSize(size.text());
                        shirtsInstance.setImageURL(img);
                        this.getShirtsDAO().findShirtsInstance(shirtsInstance);

                        //Set and add shirts comparison to database
                        ShirtsCompare shirtsComparison = new ShirtsCompare();
                        shirtsComparison.setShirtsInstance(this.getShirtsDAO().findShirtsInstance(shirtsInstance));
                        shirtsComparison.setPrice(Float.parseFloat(price));
                        shirtsComparison.setWebsiteURL("https://www.footy.com/" + url);
                        this.getShirtsDAO().findShirtsComparison(shirtsComparison);

                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            //Sleep for the crawl delay, which is in seconds
            try {
                sleep(this.getScrapeDelay());//Sleep is in milliseconds, so we need to multiply the crawl delay by 1000
            } catch (InterruptedException ex) {
                System.err.println(ex.getMessage());
            }
        }
    }

    public void setShirtsDAO(ShirtsDAO shirtsDAO) {
    }

    public void setShirtsDA(ShirtsDAO shirtsDAO) {
    }
}
