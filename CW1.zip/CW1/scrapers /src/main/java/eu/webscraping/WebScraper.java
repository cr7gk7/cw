package eu.webscraping;

/**
 * WebScraper extends Thread and parent class from where the
 * scrapers extend
 */
public class WebScraper extends Thread{

    private int scrapeDelay;
    private ShirtsDAO shirtsDAO;
    volatile private boolean runThread = true;

    public int getScrapeDelay() {
        return scrapeDelay;
    }

    public void setScrapeDelay(int scrapeDelay) {
        this.scrapeDelay = scrapeDelay;
    }

    public ShirtsDAO getShirtsDAO() {
        return shirtsDAO;
    }

    public void setShirtsDAO(ShirtsDAO shirtsDAO) {
        this.shirtsDAO = shirtsDAO;
    }

    public boolean setRunThread(){
        return runThread;
    }

    public void stopScraping(){
        this.runThread = false;
    }
}
