package eu.webscraping;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Wiggle class from where shirts are loaded to database
 */
public class SportsDirect extends WebScraper {

    /**
     * Function to run thread
     */
    @Override
    public void run() {

        //While loop will keep running until runThread is set to false
        while (this.setRunThread()) {

            try {

                //Array that contains all urls to be scraped
                String[] query = {"https://www.sportsdirect.com/football-shirts/premier-league-football-shirts"};

                for (int i = 0; i < query.length; i++) {

                    WebDriver driver = new ChromeDriver();

                    driver.get(query[i]);

                    Document doc = Jsoup.parse(driver.getPageSource());

                    Elements products = doc.select("div .bem-product-list--grid .bem-product-list-item--grid");

                    for (int j = 0; j < products.size(); j++) {

                        Elements title = products.get(j).select("div .bem-product-thumb--grid .bem-product-thumb__image-link--grid");

                        Elements image = products.get(j).select("div .bem-product-thumb--grid .bem-product-thumb__image-link--grid .lazy");

                        Elements price = products.get(j).select("div .bem-product-thumb--grid .bem-product-price--grid .bem-product-price__unit--grid");

                        String description = title.attr("title");

                        String[] line = description.split("[(|:|)]");

                        String filter1 = line[0];

                        String[] filter2 = filter1.split(" ");

                        String brand = filter2[0];

                        String model = filter1.replaceAll(brand, "").replaceAll("Football Shirts>Premier League Football Shirts & Kits", "").trim();

                        String url = title.attr("href");

                        String img = image.attr("data-original");

                        String outputImg = "https:" + img;

                        String filter = "";

                        String outputPrice = "";

                        if (price.text().length() > 10) {

                            String[] bits = price.text().split("-");

                            filter = bits[0];

                            outputPrice = filter.replaceAll("£|,", "").trim();

                        } else {

                            outputPrice = price.text().replaceAll("£|,", "").trim();

                        }

                        //Set and add shirts model to database
                        ShirtsModel shirtsModel = new ShirtsModel();
                        shirtsModel.setManufacturer(brand);
                        shirtsModel.setModel(model);
                        this.getShirtsDAO().findShirtsModel(shirtsModel);

                        //Set and add shirts instance to database
                        ShirtsInstance shirtsInstance = new ShirtsInstance();
                        shirtsInstance.setShirtsModel(getShirtsDAO().findShirtsModel(shirtsModel));
                        shirtsInstance.setDescription(description);
                        shirtsInstance.setSize("N/A");
                        shirtsInstance.setColor("N/A");
                        shirtsInstance.setImageURL(outputImg);
                        this.getShirtsDAO().findShirtsInstance(shirtsInstance);

                        //Set and add shirts comparison to database
                        ShirtsCompare shirtsComparison = new ShirtsCompare();
                        shirtsComparison.setShirtsInstance(getShirtsDAO().findShirtsInstance(shirtsInstance));
                        shirtsComparison.setPrice(Float.parseFloat(outputPrice));
                        shirtsComparison.setWebsiteURL(url);
                        this.getShirtsDAO().findShirtsComparison(shirtsComparison);

                    }
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

            //Sleep for the crawl delay, which is in seconds
            try {
                sleep(this.getScrapeDelay());//Sleep is in milliseconds, so we need to multiply the crawl delay by 1000
            } catch (InterruptedException ex) {
                System.err.println(ex.getMessage());
            }
        }
    }

    public void setShirtsDAO(ShirtsDAO shirtsDAO) {
    }
}
