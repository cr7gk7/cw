package eu.webscraping;

import javax.persistence.*;

/**
 * Class mapped to shirts_instance table
 */
@Entity
@Table(name = "shirts_instance")
public class ShirtsInstance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name="shirts_model_id", nullable=false)
    ShirtsModel shirtsModel;

    @Column(name = "description")
    private String description;

    @Column(name = "color")
    private String color;

    @Column(name = "size")
    private String size;

    @Column(name = "image_url")
    private String imageURL;

    public ShirtsInstance() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ShirtsModel getShirtsModel() {
        return shirtsModel;
    }

    public void setShirtsModel(ShirtsModel shirts_model_id) {
        this.shirtsModel = shirts_model_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    @Override
    public String toString() {
        return "ShirtsInstance{" +
                "id=" + id +
                ", shirtsModel=" + shirtsModel +
                ", description='" + description + '\'' +
                ", color='" + color + '\'' +
                ", size='" + size + '\'' +
                ", imageURL='" + imageURL + '\'' +
                '}';
    }

    public void setShirtsModel(ShirtsModel shirtsModel) {
    }
}
