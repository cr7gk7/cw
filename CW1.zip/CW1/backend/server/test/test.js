let chai = require('chai');
let server = require('../app');

let chaiHttp = require('chai-http');
chai.use(chaiHttp);
chai.should();

//Test for query search that checks if a array of shirts is returned
describe('/GET search', () => {

    it('it should GET all the shirts searched', (done) => {
        chai.request(server)
            .get("/api/search/trek?num_items=6&offset=0")
            .end((err, res) => {
                res.should.have.status(200);
                let resObj = JSON.parse(res.text);
                resObj.data.should.be.a('array');
                resObj.data.length.should.not.be.eq(0);
                done();
            });
    });

});

//Test for query count numbers checks if a count of shirts is returned
describe('/GET count number', () => {

    it('it should GET all the shirts count', (done) => {
        chai.request(server)
            .get("/api/search/trek?num_items=6&offset=0")
            .end((err, res) => {
                res.should.have.status(200);
                let resObj = JSON.parse(res.text);
                let count = resObj.count;
                count.should.not.be.eq(0);
                done();
            });
    });

});

//Test for query shirts model checks if an array of models is returned
describe('/GET shirts model', () => {

    it('it should GET shirts model', (done) => {
        chai.request(server)
            .get("/api/shirts/marlin")
            .end((err, res) => {
                res.should.have.status(200);
                let resObj = JSON.parse(res.text);
                resObj.should.be.a('array');
                resObj.length.should.not.be.eq(0);
                done();
            });
    });
});

//Test for query shirts instance checks if an array of instances is returned
describe('/GET shirts instance', () => {

    it('it should GET shirts instance', (done) => {
        chai.request(server)
            .get("/api/shirt_instance/1")
            .end((err, res) => {
                res.should.have.status(200);
                let resObj = JSON.parse(res.text);
                resObj.should.be.a('array');
                resObj.length.should.not.be.eq(0);
                done();
            });
    });
});

//Test for query shirts model comparison if an array of comparisons is returned
describe('/GET shirts comparison', () => {

    it('it should GET shirts comparison', (done) => {
        chai.request(server)
            .get("/api/compare/1")
            .end((err, res) => {
                res.should.have.status(200);
                let resObj = JSON.parse(res.text);
                resObj.should.be.a('array');
                resObj.length.should.not.be.eq(0);
                done();
            });
    });
});




